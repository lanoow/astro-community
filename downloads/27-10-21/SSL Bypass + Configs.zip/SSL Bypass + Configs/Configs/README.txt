If Engine.ini file gets cleaned after game launch, enable reading only function in file properties - Если ваш Engine.ini файл становится пустым после запуска игры, установите галочку только чтение в свойсвах файла.

[/Script/Engine.GarbageCollectionSettings]


=== LIGHT AND EFFECTS ===
r.LightFunctionQuality=0 (Enable big red stain, that visible through walls - Включить большое красное свечение, что видно через стены) ; 1   (Return To Default - По умолчанию)
r.EmitterSpawnRateScale=[0.00-1.00]   (Setting up effects spawn rate, like fog - Настройка кол-ва эффектов на экране, туман например)


=== SHADOWS ===
r.ShadowQuality=[0-4]   (Setting up Shadows Quality, works not well in DBD - Настроить качество теней, неправильно работает в DBD)
r.Shadow.DistanceScale=[0+...]   (Setting Up Shadow Draw Distance - Настроить дальность прорисовки теней)
r.Shadow.RadiusThreshold=[0+...]   (Setting Up Shadow Draw Radius - Настроить радиус прорисовки теней)
r.AllowLandscapeShadows=[0-1]   (Enable or disable landscape shadows - Включить или выключить тени от ландшафта)


=== GRAPHIC SETTINGS ===
r.MipMapLODBias=[-15 - 15 ]   (Setting up texture quality, all after 0 is bad quality - Настройка качества текстур, все после 0 в плохом качестве)
r.RenderTargetPoolMin=[VIDEO MEMORY]   (Setting Up free video card memory for all instead textures - Настраивает виделенную на все процессы, кроме текстур видеопамять)
r.DefaultFeature.AntiAliasing=[0-4]   (Setting up antialising quality, 0 = disabled - Настроить качество сглаживания, 0 = отключено)
r.MaxAnisotropy=[0-16]   (Setting Up Anisotropy quality - Настроить качество Анизотропной Фильтрации)


=== VIEW DISTANCE SETTINGS ===
r.ViewDistanceScale=[0.000 - 1.000+]   (Setting Up draw distance of all objects in the game - Настроить дальность прорисовки)
r.StaticMeshLODDistanceScale=[0.000 - 1.000+]   (Controls LOD model draw distance, also needed to make work parametr listed bellow - Настраивает дальность прорисовки LOD моделей, так же необходим что бы приведенный ниже параметр работал)
r.SkeletalMeshLODBias=[0 - 5]   (This parametr controls LOD model quality, selected number of LOD will be applied to all the characters and props on the map - Данный параметр контролирует качество LOD моделей в целом, указанный уровень будет применен ко всем персонажам и моделям в игре)

[/Script/Engine.LocalPlayer]
AspectRatioAxisConstraint= [AspectRatio_MaintainXFOV  |  AspectRatio_MaintainYFOV]   (X = FOV DEFAULT ; Y = FOV 120)